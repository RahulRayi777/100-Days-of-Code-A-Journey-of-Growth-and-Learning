'''__init__.py is a special file used in Python to define
 packages and initialize their namespaces
 '''